from flask import Flask, render_template, request, redirect, url_for, jsonify
import pyodbc
import re
from conversion_state import (
    load_state, new_conversion, finish_conversion, update_cleanup_state,
    start_utf8_phase, update_utf8_state, complete_utf8_phase
)
from workflows import TESTING_PHASES, LIVE_PHASES

app = Flask(__name__)

CHECKS = [
    {"name": "Department Codes", "table": "department_tb", "column": "de_code"},
    {"name": "Category Codes", "table": "category_tb", "column": "ca_code"},
    {"name": "Color Codes", "table": "color_tb", "column": "co_code"},
    {"name": "Size Codes", "table": "size_tb", "column": "sz_code"},
    {"name": "Inventory ISBN", "table": "inventory_table", "column": "in_isbn"},
    {"name": "ISBN In Use", "table": "isbn_in_use_tb", "column": "c_isbn"},
    {"name": "Alternate SKU", "table": "alternate_sku_tb", "column": "as_alt_sku"},
    {"name": "Inventory Master SKU", "table": "inventory_table", "column": "in_master_sku"},
    {"name": "Vendor Codes", "table": "vendor_tb", "column": "ve_code", "vendor_dependencies": True},
    {
        "name": "College Course Names",
        "table": "college_course_tb",
        "column": "course_name",
        "bad_chars": [9, 10, 11, 12, 13, 32, 146, 147],
        "manual_review_chars": [13, 146, 147],
    },
    {
        "name": "Section Numbers",
        "table": "section_tb",
        "column": "section_number",
        "bad_chars": [9, 10, 11, 12, 13, 32, 146, 147],
        "manual_review_chars": [13, 146, 147],
    },
]

BAD_CHARS = {
    9: "[TAB]",
    10: "[LF]",
    11: "[VT]",
    12: "[FF]",
    13: "[CR]",
    32: "[SPACE]",
    146: "[CHAR 146]",
    147: "[CHAR 147]",
}

DEFAULT_BAD_CHAR_CODES = [9, 10, 11, 12, 32]

PAYMENT_CHECKS = [
    {"table": "payment_post_tb", "column": "pp_id"},
    {"table": "payment_item_tb", "column": "pp_id"},
    {"table": "payment_form_tb", "column": "pp_id"},
    {"table": "payment_cc_tb", "column": "pp_id"},
]
PAYMENT_REVIEW_ID = "999999999"


VENDOR_REFERENCES = [
    {"label": "Inventory Vendor 1", "table": "inventory_table", "column": "in_vendor1", "active_filter": "in_flag_delete = 'F'"},
    {"label": "Inventory Vendor 2", "table": "inventory_table", "column": "in_vendor2", "active_filter": "in_flag_delete = 'F'"},
    {"label": "Inventory Vendor 3", "table": "inventory_table", "column": "in_vendor3", "active_filter": "in_flag_delete = 'F'"},
    {"label": "Monthly Inventory by Vendor", "table": "monthly_inventory_by_vendor_tb", "column": "ve_code"},
    {"label": "Purchase Header", "table": "purchase_header_tb", "column": "ve_code"},
    {"label": "PO Header", "table": "po_header_tb", "column": "ve_code"},
    {"label": "Return Header", "table": "return_header_tb", "column": "ve_code"},
    {"label": "Retail Return Header", "table": "ret_header_tb", "column": "ve_code"},
    {"label": "Scrap Header", "table": "scrap_header_tb", "column": "ve_code"},
    {"label": "PO Backorder Note", "table": "po_backorder_note_tb", "column": "ve_code"},
    {"label": "Deleted Purchase Header", "table": "deleted_purchase_header_tb", "column": "ve_code"},
    {"label": "Wantlist Header", "table": "wantlist_header_tb", "column": "ve_code"},
    {"label": "PO Item Work", "table": "po_item_work_tb", "column": "ve_code"},
    {"label": "Wholesale Return Header", "table": "ret_header_whl_tb", "column": "ve_code"},
    {"label": "Receiving", "table": "receiving_tb", "column": "ve_code"},
]



def visible_user_id(value):
    """Make whitespace/control characters visible without altering the value before validation."""
    if value is None:
        return ""
    labels = {9: "[TAB]", 10: "[LF]", 11: "[VT]", 12: "[FF]", 13: "[CR]", 32: "[SPACE]"}
    out = []
    for ch in str(value):
        code = ord(ch)
        if code in labels:
            out.append(labels[code])
        elif code < 32 or code == 127:
            out.append(f"[CHAR {code}]")
        else:
            out.append(ch)
    return "".join(out)


def invalid_user_id_characters(value):
    """Return every non-ASCII-alphanumeric character found in the original User ID."""
    text = "" if value is None else str(value)
    invalid = []
    for ch in text:
        if not (("A" <= ch <= "Z") or ("a" <= ch <= "z") or ("0" <= ch <= "9")):
            code = ord(ch)
            labels = {9: "[TAB]", 10: "[LF]", 11: "[VT]", 12: "[FF]", 13: "[CR]", 32: "[SPACE]"}
            invalid.append(labels.get(code, ch if code >= 32 and code != 127 else f"[CHAR {code}]"))
    return invalid


def run_user_id_check(conn):
    """Read-only validation of active Booklog User IDs."""
    cur = conn.cursor()
    cur.execute("SELECT us_userid FROM \"GROUP1\".\"user_tb\" WHERE us_deleted = '0'")
    rows = cur.fetchall()
    cur.close()

    invalid_users = []
    for row in rows:
        raw = "" if row[0] is None else str(row[0])
        invalid = invalid_user_id_characters(raw)
        if invalid:
            invalid_users.append({
                "raw": raw,
                "visible": visible_user_id(raw),
                "invalid_characters": invalid,
            })

    return {
        "total_active": len(rows),
        "invalid_users": invalid_users,
        "invalid_count": len(invalid_users),
        "status": "review" if invalid_users else "pass",
    }

def get_dsns():
    return sorted(pyodbc.dataSources().keys())


def connect(dsn):
    return pyodbc.connect(f"DSN={dsn}", autocommit=False)


def verify_connection(conn):
    cur = conn.cursor()
    cur.execute('SELECT st_storename FROM "GROUP1"."store_tb"')
    store_names = [row[0] for row in cur.fetchall()]
    cur.close()
    return store_names


def visible_value(value, bad_char_codes=None):
    if value is None:
        return ""
    text = str(value)
    codes = bad_char_codes or DEFAULT_BAD_CHAR_CODES
    for code in codes:
        text = text.replace(chr(code), BAD_CHARS[code])
    return text


def bad_character_labels(value, bad_char_codes=None):
    if value is None:
        return []
    text = str(value)
    codes = bad_char_codes or DEFAULT_BAD_CHAR_CODES
    return [BAD_CHARS[code] for code in codes if chr(code) in text]


def cleaned_value(value, bad_char_codes=None):
    if value is None:
        return ""
    codes = set(bad_char_codes or DEFAULT_BAD_CHAR_CODES)
    return "".join(ch for ch in str(value) if ord(ch) not in codes)


def get_vendor_dependencies(conn, bad_code, cleaned_code):
    cur = conn.cursor()
    dependencies = []

    for ref in VENDOR_REFERENCES:
        table = ref["table"]
        column = ref["column"]
        active_filter = ref.get("active_filter")

        bad_sql = f'SELECT COUNT(*) FROM "GROUP1"."{table}" WHERE "{column}" = ?'
        clean_sql = f'SELECT COUNT(*) FROM "GROUP1"."{table}" WHERE "{column}" = ?'

        if active_filter:
            bad_sql += f" AND {active_filter}"
            clean_sql += f" AND {active_filter}"

        cur.execute(bad_sql, bad_code)
        bad_count = cur.fetchone()[0]

        cur.execute(clean_sql, cleaned_code)
        cleaned_count = cur.fetchone()[0]

        dependencies.append({
            **ref,
            "bad_count": bad_count,
            "cleaned_count": cleaned_count,
        })

    cur.close()
    return dependencies



def sql_literal(value):
    """Return a display-only SQL string literal. This SQL is never executed by the app."""
    if value is None:
        return "NULL"

    text = str(value)
    parts = []
    buffer = ""

    def flush_buffer():
        nonlocal buffer
        if buffer:
            parts.append("'" + buffer.replace("'", "''") + "'")
            buffer = ""

    for ch in text:
        code = ord(ch)
        if code in BAD_CHARS:
            flush_buffer()
            parts.append(f"CHAR({code})")
        else:
            buffer += ch

    flush_buffer()
    return " + ".join(parts) if parts else "''"


def suggested_cleanup_sql(table, column, current_value, cleaned_value):
    return (
        f'UPDATE "GROUP1"."{table}"\n'
        f'SET "{column}" = {sql_literal(cleaned_value)}\n'
        f'WHERE "{column}" = {sql_literal(current_value)};'
    )


def vendor_value_exists(conn, value):
    """Read-only uniqueness check for a proposed vendor code."""
    cur = conn.cursor()
    cur.execute('SELECT COUNT(*) FROM "GROUP1"."vendor_tb" WHERE "ve_code" = ?', value)
    count = cur.fetchone()[0]
    cur.close()
    return count


def suggested_vendor_cleanup_sql(current_value, final_value, dependencies):
    """Build display-only vendor correction SQL. Nothing returned here is executed by the app."""
    statements = []

    for dep in dependencies:
        if dep["bad_count"] <= 0:
            continue

        table = dep["table"]
        column = dep["column"]
        active_filter = dep.get("active_filter")

        sql = (
            f'UPDATE "GROUP1"."{table}"\n'
            f'SET "{column}" = {sql_literal(final_value)}\n'
            f'WHERE "{column}" = {sql_literal(current_value)}'
        )
        if active_filter:
            sql += f"\n  AND {active_filter}"
        sql += ";"
        statements.append(sql)

    # Update the vendor record itself last, after all known references.
    statements.append(
        f'UPDATE "GROUP1"."vendor_tb"\n'
        f'SET "ve_code" = {sql_literal(final_value)}\n'
        f'WHERE "ve_code" = {sql_literal(current_value)};'
    )

    return "\n\n".join(statements)


def run_check(conn, check):
    table = check["table"]
    column = check["column"]
    bad_char_codes = check.get("bad_chars", DEFAULT_BAD_CHAR_CODES)
    manual_review_chars = set(check.get("manual_review_chars", []))
    cur = conn.cursor()

    cur.execute(f'SELECT COUNT(*) FROM "GROUP1"."{table}"')
    total_records = cur.fetchone()[0]

    conditions = []
    for code in bad_char_codes:
        # Preserve existing company behavior: CHAR(32) means trailing space only.
        if code == 32:
            conditions.append(f'"{column}" LIKE \'%\' + CHAR(32)')
        else:
            conditions.append(f'"{column}" LIKE \'%\' + CHAR({code}) + \'%\'')

    where_clause = "\n           OR ".join(conditions)
    sql = f"""
        SELECT "{column}"
        FROM "GROUP1"."{table}"
        WHERE {where_clause}
        ORDER BY "{column}"
    """
    cur.execute(sql)
    values = [row[0] for row in cur.fetchall()]

    rows = []
    for value in values:
        text_value = "" if value is None else str(value)
        found_codes = {code for code in bad_char_codes if chr(code) in text_value}
        requires_manual_review = bool(found_codes & manual_review_chars)

        cleaned = cleaned_value(value, bad_char_codes)
        cur.execute(
            f'SELECT COUNT(*) FROM "GROUP1"."{table}" WHERE "{column}" = ?',
            cleaned,
        )
        collision_count = cur.fetchone()[0]

        row = {
            "current": visible_value(value, bad_char_codes),
            "problem": ", ".join(bad_character_labels(value, bad_char_codes)),
            "cleaned": (
                "Manual review — cleanup rule not established"
                if requires_manual_review
                else visible_value(cleaned, bad_char_codes)
            ),
            "default_final": "" if (requires_manual_review or (check.get("vendor_dependencies") and collision_count > 0)) else visible_value(cleaned, bad_char_codes),
            "record_key": f"{table}|{column}|{visible_value(value, bad_char_codes)}",
            "collision_count": collision_count,
            "status": "review" if requires_manual_review or collision_count > 0 else "safe",
            "manual_review": requires_manual_review,
        }

        if check.get("vendor_dependencies"):
            dependencies = get_vendor_dependencies(conn, value, cleaned)
            row["dependencies"] = dependencies
            row["bad_reference_count"] = sum(dep["bad_count"] for dep in dependencies)
            row["cleaned_reference_count"] = sum(dep["cleaned_count"] for dep in dependencies)

        # Display-only suggestion for straightforward SAFE CLEANUP cases.
        if row["status"] == "safe" and not check.get("vendor_dependencies"):
            row["suggested_sql"] = suggested_cleanup_sql(table, column, value, cleaned)
        else:
            row["suggested_sql"] = None

        rows.append(row)

    cur.close()
    return {
        **check,
        "rows": rows,
        "total_records": total_records,
        "problem_count": len(rows),
        "safe_count": sum(1 for row in rows if row["status"] == "safe"),
        "review_count": sum(1 for row in rows if row["status"] == "review"),
    }


def run_payment_checks(conn):
    """Read-only payment checks matching the existing TOP 1 / ORDER BY pp_id DESC workflow."""
    checks = []

    for check in PAYMENT_CHECKS:
        table = check["table"]
        column = check["column"]
        cur = conn.cursor()
        cur.execute(
            f'SELECT TOP 1 * FROM "GROUP1"."{table}" ORDER BY "{column}" DESC'
        )
        row = cur.fetchone()
        columns = [description[0] for description in cur.description] if cur.description else []

        if row is None:
            highest_pp_id = None
            row_details = []
        else:
            values = list(row)
            row_data = dict(zip(columns, values))
            highest_pp_id = row_data.get(column)

            # Fall back to a case-insensitive lookup if the ODBC driver changes column-name casing.
            if highest_pp_id is None:
                for key, value in row_data.items():
                    if key.lower() == column.lower():
                        highest_pp_id = value
                        break

            row_details = [
                {"column": key, "value": "" if value is None else str(value)}
                for key, value in row_data.items()
            ]

        highest_text = "" if highest_pp_id is None else str(highest_pp_id).strip()
        requires_review = highest_text == PAYMENT_REVIEW_ID

        checks.append({
            **check,
            "highest_pp_id": highest_text,
            "display_highest_pp_id": highest_text if highest_text else "No records",
            "requires_review": requires_review,
            "row_details": row_details if requires_review else [],
            "suggested_delete_sql": (
                f'DELETE FROM "GROUP1"."{table}" WHERE "{column}" = \'{PAYMENT_REVIEW_ID}\';'
                if requires_review else None
            ),
        })
        cur.close()

    return checks


def run_suspend_constraint_check(conn):
    """Read-only check of constraints referencing GROUP1.suspend_header_tb."""
    cur = conn.cursor()
    cur.execute("""
        SELECT foreign_creator, foreign_tname, primary_creator, primary_tname, role, columns
        FROM SYS.SYSFOREIGNKEYS
        WHERE primary_creator = 'GROUP1'
          AND primary_tname = 'suspend_header_tb'
        ORDER BY role
    """)
    constraints = [{
        "foreign_creator": str(r[0]), "foreign_tname": str(r[1]),
        "primary_creator": str(r[2]), "primary_tname": str(r[3]),
        "role": str(r[4]), "columns": str(r[5]),
    } for r in cur.fetchall()]
    cur.close()

    expected = [c for c in constraints
        if c["foreign_creator"] == "GROUP1"
        and c["foreign_tname"] == "suspend_item_tb"
        and c["role"] == "suspend_header_tb"]

    numbered = re.compile(r"^suspend_header_tb(?:00[1-9]|01[0-9]|020)$")
    removable = [c for c in constraints
        if c["foreign_creator"] == "GROUP1"
        and c["foreign_tname"] == "suspend_item_tb"
        and numbered.fullmatch(c["role"])]

    known_roles = {c["role"] for c in expected + removable}
    unexpected = [c for c in constraints if c["role"] not in known_roles]
    status = "review" if len(expected) != 1 or unexpected else ("safe" if removable else "pass")

    sql = "\n\n".join(
        f'ALTER TABLE "GROUP1"."{c["foreign_tname"]}" DROP CONSTRAINT "{c["role"]}";'
        for c in removable
    )
    return {"constraints": constraints, "removable": removable,
            "unexpected": unexpected, "status": status, "suggested_sql": sql}


def run_all_checks(conn):
    return [run_check(conn, check) for check in CHECKS]



@app.route("/vendor-suggestion", methods=["POST"])
def vendor_suggestion():
    """Read-only endpoint: verify a proposed vendor code and return display-only SQL."""
    data = request.get_json(silent=True) or {}
    dsn = data.get("dsn", "").strip()
    current_visible = data.get("current", "")
    final_value = data.get("final", "").strip()

    if not dsn or not current_visible or not final_value:
        return {"ok": False, "error": "Database, current vendor code, and final vendor code are required."}, 400

    # Convert the UI's visible markers back to the original characters.
    current_value = current_visible
    for code, label in BAD_CHARS.items():
        current_value = current_value.replace(label, chr(code))

    conn = None
    try:
        conn = connect(dsn)

        existing_count = vendor_value_exists(conn, final_value)
        if existing_count > 0:
            conn.rollback()
            return {
                "ok": True,
                "unique": False,
                "existing_count": existing_count,
                "sql": None,
            }

        dependencies = get_vendor_dependencies(conn, current_value, final_value)
        sql = suggested_vendor_cleanup_sql(current_value, final_value, dependencies)
        conn.rollback()

        return {
            "ok": True,
            "unique": True,
            "existing_count": 0,
            "sql": sql,
        }
    except Exception as exc:
        if conn is not None:
            conn.rollback()
        return {"ok": False, "error": str(exc)}, 500
    finally:
        if conn is not None:
            conn.close()


def check_multibyte_charset(conn):
    """Read-only check of the SQL Anywhere database character set."""
    cur = conn.cursor()
    cur.execute("SELECT DB_PROPERTY( 'MultibyteCharSet' )")
    row = cur.fetchone()
    cur.close()
    return "" if not row or row[0] is None else str(row[0]).strip()


def _odbc_value(value):
    """Brace/escape an ODBC connection-string value without logging it."""
    return "{" + str(value).replace("}", "}}") + "}"


def sql_anywhere_driver():
    """Return the installed SQL Anywhere 12 ODBC driver name when available."""
    drivers = list(pyodbc.drivers())
    for driver in drivers:
        if driver.lower() == "sql anywhere 12":
            return driver
    matches = [d for d in drivers if "sql anywhere" in d.lower()]
    if matches:
        return matches[0]
    raise RuntimeError("No SQL Anywhere ODBC driver was found on this computer.")


def connect_running_utf8_database(password):
    """Connect to the user-started local blwmed database without a DSN or autostart."""
    driver = sql_anywhere_driver()
    connection_string = (
        f"DRIVER={_odbc_value(driver)};"
        "UID=dba;"
        f"PWD={_odbc_value(password)};"
        "ENG=blwmed;"
        "DBN=blwmed;"
        "LINKS=SharedMemory;"
    )
    return pyodbc.connect(connection_string, autocommit=False)


def inspect_utf8_database(conn):
    """Read-only identity and character-set verification for the running replacement DB."""
    cur = conn.cursor()
    cur.execute("""
        SELECT PROPERTY('Name'),
               DB_PROPERTY('Name'),
               DB_PROPERTY('File'),
               DB_PROPERTY('MultibyteCharSet')
    """)
    row = cur.fetchone()
    cur.close()
    if not row:
        raise RuntimeError("SQL Anywhere returned no database information.")
    return {
        "server_name": "" if row[0] is None else str(row[0]).strip(),
        "database_name": "" if row[1] is None else str(row[1]).strip(),
        "database_file": "" if row[2] is None else str(row[2]).strip(),
        "charset_result": "" if row[3] is None else str(row[3]).strip(),
    }


@app.route("/", methods=["GET"])
def home():
    state = load_state()
    return render_template("home.html", state=state, testing_phases=TESTING_PHASES, live_phases=LIVE_PHASES)


@app.route("/start-testing", methods=["POST"])
def start_testing():
    customer = request.form.get("customer", "").strip()
    if not customer:
        return render_template("home.html", state=None, testing_phases=TESTING_PHASES,
                               live_phases=LIVE_PHASES, error="Enter a customer or store name.")
    new_conversion(customer)
    return redirect(url_for("testing_cleanup"))


@app.route("/finish-conversion", methods=["POST"])
def finish_active_conversion():
    finish_conversion()
    return redirect(url_for("home"))


@app.route("/testing/cleanup/complete", methods=["POST"])
def complete_testing_cleanup():
    if not load_state():
        return redirect(url_for("home"))
    start_utf8_phase()
    return redirect(url_for("testing_utf8"))


@app.route("/testing/utf8", methods=["GET", "POST"])
def testing_utf8():
    state = load_state()
    if not state:
        return redirect(url_for("home"))

    dsns = get_dsns()
    utf8_saved = state.get("testing", {}).get("phases", {}).get("utf8_conversion", {}).get("ui_state", {})
    selected_dsn = request.form.get("dsn", "") if request.method == "POST" else ""
    if not selected_dsn:
        selected_dsn = utf8_saved.get("dsn") or state.get("testing", {}).get("dsn", "")

    initial_charset_result = utf8_saved.get("initial_charset_result")
    # Backward compatibility with V1.13 state files.
    if initial_charset_result is None:
        initial_charset_result = utf8_saved.get("charset_result")
    replacement_verification = utf8_saved.get("replacement_verification")
    error = None

    if request.method == "POST":
        action = request.form.get("action", "check_existing")
        if action == "check_existing":
            if not selected_dsn:
                error = "Select an ODBC data source."
            else:
                conn = None
                try:
                    conn = connect(selected_dsn)
                    verify_connection(conn)
                    initial_charset_result = check_multibyte_charset(conn)
                    conn.rollback()
                    update_utf8_state({
                        "dsn": selected_dsn,
                        "initial_charset_result": initial_charset_result,
                        "replacement_verification": None,
                    })
                    state = load_state()
                    utf8_saved = state.get("testing", {}).get("phases", {}).get("utf8_conversion", {}).get("ui_state", {})
                    replacement_verification = None
                except Exception as exc:
                    error = str(exc)
                finally:
                    if conn is not None:
                        conn.close()

        elif action == "verify_replacement":
            password = request.form.get("dba_password", "")
            if not password:
                error = "Enter the DBA password for the running replacement database."
            else:
                conn = None
                try:
                    conn = connect_running_utf8_database(password)
                    details = inspect_utf8_database(conn)
                    conn.rollback()
                    if details["server_name"].lower() != "blwmed" or details["database_name"].lower() != "blwmed":
                        raise RuntimeError(
                            "Connected to an unexpected SQL Anywhere database. "
                            f"Server={details['server_name'] or '(blank)'}, "
                            f"Database={details['database_name'] or '(blank)'}."
                        )
                    replacement_verification = details
                    update_utf8_state({"replacement_verification": details})
                    state = load_state()
                    utf8_saved = state.get("testing", {}).get("phases", {}).get("utf8_conversion", {}).get("ui_state", {})
                except Exception as exc:
                    error = str(exc)
                finally:
                    if conn is not None:
                        conn.close()

        elif action == "complete":
            initial_on = str(initial_charset_result or "").lower() == "on"
            replacement_on = (
                isinstance(replacement_verification, dict)
                and str(replacement_verification.get("charset_result", "")).lower() == "on"
            )
            if not (initial_on or replacement_on):
                error = "Verify that MultibyteCharSet is On before completing this phase."
            else:
                complete_utf8_phase()
                return redirect(url_for("home"))

    return render_template(
        "utf8.html", state=state, testing_phases=TESTING_PHASES, live_phases=LIVE_PHASES,
        dsns=dsns, selected_dsn=selected_dsn, initial_charset_result=initial_charset_result,
        replacement_verification=replacement_verification, utf8_saved=utf8_saved, error=error
    )


@app.route("/testing/utf8/state", methods=["POST"])
def save_testing_utf8_state():
    if not load_state():
        return jsonify({"ok": False, "error": "No active conversion."}), 409
    data = request.get_json(silent=True) or {}
    # Only UI progress is accepted here; database status comes from the server-side check.
    update_utf8_state({"steps": data.get("steps", {})})
    return jsonify({"ok": True})


@app.route("/testing/cleanup", methods=["GET", "POST"])
def testing_cleanup():
    state = load_state()
    if not state:
        return redirect(url_for("home"))

    dsns = get_dsns()
    selected_dsn = state.get("testing", {}).get("dsn", "")
    store_names = None
    results = None
    payment_results = None
    suspend_constraint_result = None
    user_id_result = None
    error = None

    if request.method == "POST":
        selected_dsn = request.form.get("dsn", "")
        if not selected_dsn:
            error = "Select an ODBC data source."
        else:
            conn = None
            try:
                conn = connect(selected_dsn)
                store_names = verify_connection(conn)
                results = run_all_checks(conn)
                payment_results = run_payment_checks(conn)
                suspend_constraint_result = run_suspend_constraint_check(conn)
                user_id_result = run_user_id_check(conn)
                conn.rollback()
                update_cleanup_state({"dsn": selected_dsn})
                state = load_state()
            except Exception as exc:
                error = str(exc)
            finally:
                if conn is not None:
                    conn.close()

    return render_template(
        "cleanup.html",
        state=state,
        testing_phases=TESTING_PHASES,
        live_phases=LIVE_PHASES,
        dsns=dsns,
        selected_dsn=selected_dsn,
        store_names=store_names,
        results=results,
        checks=results,
        payment_results=payment_results,
        suspend_constraint_result=suspend_constraint_result,
        user_id_result=user_id_result,
        cleanup_saved=state.get("testing", {}).get("phases", {}).get("database_validation", {}).get("ui_state", {}),
        error=error,
    )


@app.route("/testing/cleanup/state", methods=["POST"])
def save_testing_cleanup_state():
    if not load_state():
        return jsonify({"ok": False, "error": "No active conversion."}), 409
    data = request.get_json(silent=True) or {}
    update_cleanup_state({"ui_state": data})
    return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5051, debug=False)
