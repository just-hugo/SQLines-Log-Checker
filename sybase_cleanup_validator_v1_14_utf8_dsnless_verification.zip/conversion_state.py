import json
import os
from datetime import datetime
from pathlib import Path


def _data_dir():
    base = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "BooklogConversionAssistant"
    base.mkdir(parents=True, exist_ok=True)
    return base


STATE_FILE = _data_dir() / "conversion_state.json"


def load_state():
    if not STATE_FILE.exists():
        return None
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def save_state(state):
    tmp = STATE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, STATE_FILE)


def new_conversion(customer):
    now = datetime.now().isoformat(timespec="seconds")
    state = {
        "customer": customer,
        "created_at": now,
        "stage": "testing",
        "testing": {
            "status": "in_progress",
            "dsn": "",
            "current_phase": "database_validation",
            "phases": {
                "database_validation": {"status": "in_progress", "ui_state": {}},
                "utf8_conversion": {"status": "not_started", "ui_state": {}},
            },
            "findings": {}
        },
        "live": {
            "status": "not_started",
            "current_phase": None,
            "phases": {},
            "findings": {}
        }
    }
    save_state(state)
    return state


def update_cleanup_state(changes):
    state = load_state()
    if not state:
        return None
    testing = state.setdefault("testing", {})
    if "dsn" in changes:
        testing["dsn"] = changes["dsn"]
    phase = testing.setdefault("phases", {}).setdefault("database_validation", {})
    if "ui_state" in changes:
        phase["ui_state"] = changes["ui_state"]
    phase.setdefault("status", "in_progress")
    save_state(state)
    return state


def start_utf8_phase():
    state = load_state()
    if not state:
        return None
    testing = state.setdefault("testing", {})
    testing["current_phase"] = "utf8_conversion"
    phases = testing.setdefault("phases", {})
    phases.setdefault("database_validation", {})["status"] = "complete"
    phases.setdefault("utf8_conversion", {"ui_state": {}})["status"] = "in_progress"
    save_state(state)
    return state


def update_utf8_state(changes):
    state = load_state()
    if not state:
        return None
    testing = state.setdefault("testing", {})
    phase = testing.setdefault("phases", {}).setdefault(
        "utf8_conversion", {"status": "in_progress", "ui_state": {}}
    )
    phase.setdefault("status", "in_progress")
    ui_state = phase.setdefault("ui_state", {})
    ui_state.update(changes)
    save_state(state)
    return state


def complete_utf8_phase():
    state = load_state()
    if not state:
        return None
    testing = state.setdefault("testing", {})
    phase = testing.setdefault("phases", {}).setdefault("utf8_conversion", {})
    phase["status"] = "complete"
    testing["current_phase"] = "database_creation"
    testing.setdefault("phases", {}).setdefault("database_creation", {"status": "not_started", "ui_state": {}})
    save_state(state)
    return state


def finish_conversion():
    if STATE_FILE.exists():
        STATE_FILE.unlink()
