TESTING_PHASES = [
    {"id": "preparation", "label": "Preparation", "status": "future"},
    {"id": "database_validation", "label": "Database Validation", "status": "active"},
    {"id": "utf8_conversion", "label": "UTF-8 Conversion", "status": "future"},
    {"id": "database_creation", "label": "Test Database Creation", "status": "future"},
    {"id": "sqlines_conversion", "label": "SQLines Conversion", "status": "future"},
    {"id": "testing_results", "label": "Testing Results", "status": "future"},
]

LIVE_PHASES = [
    {"id": "live_conversion", "label": "Live workflow", "status": "future"},
]
