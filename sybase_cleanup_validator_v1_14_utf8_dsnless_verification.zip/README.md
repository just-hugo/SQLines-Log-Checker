# Sybase Cleanup Validator V1.7.4

Read-only Flask/pyodbc pre-conversion validator.

V1.3 adds a reusable validation engine for:
- Department: department_tb.de_code
- Category: category_tb.ca_code
- Color: color_tb.co_code
- Size: size_tb.sz_code
- Inventory ISBN: inventory_table.in_isbn
- ISBN in use: isbn_in_use_tb.c_isbn
- Alternate SKU: alternate_sku_tb.as_alt_sku
- Inventory master SKU: inventory_table.in_master_sku

Each check reports total records, problems found, safe cleanups, review-required collisions, and expandable details.

The established query behavior is preserved: CHAR(9-12) are searched anywhere and CHAR(32) at the end.

Database identity is verified with GROUP1.store_tb.st_storename. This version executes SELECT statements only.

Windows:
    py -m venv .venv
    .\.venv\Scripts\Activate.ps1
    pip install -r requirements.txt
    py app.py

Open http://127.0.0.1:5051


## V1.4 vendor validation

Adds `vendor_tb.ve_code` to the normal bad-character/collision validation.

For each bad vendor code, the app also checks the vendor-reference locations from the supplied company vendor scripts. It reports:
- records using the bad vendor code;
- records already using the cleaned vendor code;
- counts for each dependent table/column.

Inventory vendor reference counts preserve the supplied `in_flag_delete = 'F'` rule.

The original supplied `in_vendor2` and `in_vendor3` bad-character scripts appear to begin their first OR condition with `in_vendor1`, and the supplied inventory scripts do not parenthesize the OR conditions before the `AND in_flag_delete = 'F'`. V1.4 does not reproduce those ambiguous expressions. Because the app already knows the exact bad vendor code and exact cleaned code, it uses parameterized equality checks against each correct vendor column instead.

All application database operations remain SELECT-only.


## V1.4.1 vendor dependency labels

Clarifies the vendor dependency display without changing any database queries or validation logic.

The dependency section now:
- says "Where these vendor codes are used";
- shows the actual bad vendor code in the usage label;
- shows the actual proposed cleaned code in the usage label;
- changes "Reference" to "Location";
- replaces abstract "Bad code refs" / "Cleaned code refs" headings with the actual vendor values.


## V1.5 college course and section validation

Adds `college_course_tb.course_name` and `section_tb.section_number`.

Both checks detect CHAR(9), CHAR(10), CHAR(11), CHAR(12), trailing CHAR(32), plus CHAR(13), CHAR(146), and CHAR(147). The latter three are shown as `[CR]`, `[CHAR 146]`, and `[CHAR 147]`.

Because no established cleanup rule has been supplied for CHAR(13), CHAR(146), or CHAR(147), any record containing them is marked REVIEW REQUIRED and no automatic cleaned value is proposed.

Existing checks retain their previous behavior. The application remains SELECT-only.


## V1.6 suggested cleanup SQL

For straightforward rows classified SAFE CLEANUP, the results now include an expandable display-only SQL statement showing the corresponding UPDATE.

The application does not execute these UPDATE statements. They are generated as text for manual review/copying only.

No suggested UPDATE is generated for REVIEW REQUIRED rows, vendor-code changes, or course/section rows containing CHAR(13), CHAR(146), or CHAR(147).

Generated literals preserve invisible characters explicitly with `CHAR(n)` expressions so the WHERE clause clearly identifies the bad value.


## V1.6.1 copy SQL button

Suggested cleanup SQL blocks now include a Copy button. Clicking it copies the exact generated SQL to the clipboard and briefly changes the button label to `Copied!`.

This is a UI-only convenience feature. It does not execute SQL or change the database.


## V1.7 cleanup tracking and reports
Adds a Final value field and Fixed checkbox to each detected problem. State is persisted in browser localStorage. A Reports section generates a high-level internal report and a detailed client report listing completed original-to-final changes. Reports can be copied to the clipboard. The internal wording does not mention the validator or special tooling. Sybase access remains read-only.


## V1.7.1 report formatting

Fixes the report newline bug and changes the generated reports to a more polished format.

The internal report now uses:
- a concise checklist documenting every validation performed;
- issue counts beside each check;
- a separate Corrections section only for affected record types;
- no mention of the validator, automation, Python, or other special tooling.

The client report includes only record types with completed corrections and lists each original value and final value for review.


## V1.7.2 complete internal checklist

Fixes the internal report so it lists every validation performed, including checks that returned zero issues. The report generator now receives summary metadata for the complete server-side validation results rather than trying to infer checks only from problem rows in the page.


## V1.7.3 complete report source fix

The internal report checklist now reads directly from the complete `results` collection rendered by the validation route. This fixes the previous versions' mistake of deriving the report's list of checks from DOM elements associated with problem rows.

All validation categories are therefore available to the report generator, including categories with zero issues.


## V1.7.4 initial page-load fix

Fixes the initial GET `/` server error introduced in V1.7.3. Before a validation run, `results` is `None`; the report metadata template now safely treats that state as an empty list. After a validation run, it still iterates the complete results collection so zero-issue checks are available to the internal report.

## V1.12 workflow prototype

V1.12 introduces the Conversion Assistant workflow shell while preserving the existing read-only cleanup validator.

- The application maintains one active conversion at a time.
- Working state is stored as `conversion_state.json` under `%LOCALAPPDATA%\\BooklogConversionAssistant` on Windows (or the user's home directory fallback on other systems).
- Testing Day and Live Conversion are modeled as separate stages of the same active conversion.
- Database Validation is the first functional Testing Day phase; later phases are visible as planned workflow steps.
- Cleanup completion state is saved to the active conversion state instead of browser localStorage.
- **Finish & Clear** deletes working state after reports have been saved elsewhere. It does not maintain a customer archive.
- Database access remains read-only. Generated UPDATE/DELETE/ALTER statements are display-only and are never executed by the application.
